#!/bin/sh
set -eu
cd "$(dirname "$0")"
npm install
npm start
